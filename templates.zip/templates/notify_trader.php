<?php
// Check if trader_id is set in the POST data
if(isset($_POST['trader_id'])) {
    $traderId = $_POST['trader_id'];

    // Here you can implement the logic to send the notification to the trader
    // For the sake of this example, let's just echo a success message
    echo "Notification sent to trader with ID: " . $traderId;
} else {
    // If trader_id is not set in the POST data, return an error message
    echo "Error: Trader ID not provided.";
}
?>

<?php
$con=mysqli_connect('localhost','root');
if($con){
    echo "connection successful";

}
else{
    echo "no connection ";
}

mysqli_select_db($con, 'userdata');

$tname = $_POST['tname'];
$temail= $_POST['temail'];
$tphone = $_POST['tphone'];
$taddress= $_POST['taddress'];
$websitelink= $_POST['websitelink'];
if(isset($_POST['type']) && !empty($_POST['type'])) 
{
    $type = implode(', ', $_POST['type']);
}

$minquantity= $_POST['minquantity'];
$locationrecycling= $_POST['locationrecycling'];
$transportpreference= $_POST['transportpreference'];
$specialhandling= $_POST['specialhandling'];
if(isset($_POST['paymentmethods']) && !empty($_POST['paymentmethods'])) 
{
    $paymentmethods = implode(', ', $_POST['paymentmethods']);
}

$permitslicenses= $_POST['permitslicenses'];

$query="insert into traderdata (tname,temail,tphone,taddress,
websitelink,type,minquantity,locationrecycling,transportpreference,
specialhandling,paymentmethods,permitslicenses) 
values ('$tname', '$temail','$tphone ','$taddress','$websitelink',
'$type','$minquantity','$locationrecycling','$transportpreference',
'$specialhandling','$paymentmethods','$permitslicenses')";

mysqli_query($con,$query);
header('location:page1.php');
?>
<?php include 'menu.php';
session_start();
if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = 'Guest'; // Replace with actual user name
}
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<title>Recycling Units</title>
<style>
    .container {
        height: 100vh;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }
</style>

<body>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Type</th>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Address</th>
                <th>Email</th>
                <th>Website</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $con = mysqli_connect('localhost', 'root');

            if (!$con) {
                die("Connection failed: " . mysqli_connect_error());
            }
            mysqli_select_db($con, 'userdata');

            echo "<h2>Traders Details:</h2>";

            $sql = "SELECT type, tname, tphone, taddress, temail, websitelink, tid FROM traderdata";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['type'] . "</td>";
                    echo "<td>" . $row['tname'] . "</td>";
                    echo "<td>" . $row['tphone'] . "</td>";
                    echo "<td>" . $row['taddress'] . "</td>";
                    echo "<td>" . $row['temail'] . "</td>";
                    echo "<td><a href='" . $row['websitelink'] . "'>" . $row['websitelink'] . "</a></td>";
                    echo "<td>
                            <button class='edit-btn' data-tid='" . $row['tid'] . "' data-name='" . $row['tname'] . "' data-phone='" . $row['tphone'] . "' data-address='" . $row['taddress'] . "' data-email='" . $row['temail'] . "' data-website='" . $row['websitelink'] . "'>Edit</button>
                            <button class='view-notify-btn' data-tid='" . $row['tid'] . "'>Notifications</button>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No recycling units found</td></tr>";
            }

            mysqli_close($con);
            ?>
        </tbody>
    </table>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Trader Details</h2>
            <form id="editForm">
                <input type="hidden" id="tid" name="tid">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name"><br><br>
                <label for="phone">Phone Number:</label>
                <input type="text" id="phone" name="phone"><br><br>
                <label for="address">Address:</label>
                <input type="text" id="address" name="address"><br><br>
                <label for="email">Email:</label>
                <input type="text" id="email" name="email"><br><br>
                <label for="website">Website:</label>
                <input type="text" id="website" name="website"><br><br>
                <button type="submit">Save</button>
            </form>
        </div>
    </div>

    <script>
        var modal = document.getElementById("editModal");
        var span = document.getElementsByClassName("close")[1];

        $(document).on('click', '.edit-btn', function() {
            var tid = $(this).data('tid');
            var name = $(this).data('name');
            var phone = $(this).data('phone');
            var address = $(this).data('address');
            var email = $(this).data('email');
            var website = $(this).data('website');

            $("#tid").val(tid);
            $("#name").val(name);
            $("#phone").val(phone);
            $("#address").val(address);
            $("#email").val(email);
            $("#website").val(website);

            modal.style.display = "block";
        });

        $("#editForm").submit(function(event) {
            event.preventDefault();
            var form = $(this);
            var tid = $("#tid").val();
            $.ajax({
                type: "POST",
                url: "save_changes.php",
                data: {
                    tid: tid,
                    name: $("#name").val(),
                    phone: $("#phone").val(),
                    address: $("#address").val(),
                    email: $("#email").val(),
                    website: $("#website").val()
                },
                success: function(response) {
                    alert(response);
                    modal.style.display = "none";
                }
            });
        });

        $(document).on('click', '.view-notify-btn', function() {
            var tid = $(this).data('tid');
            $('#notificationList').empty();

            $.ajax({
                url: 'get_notifications.php',
                type: 'GET',
                data: { trader_id: tid },
                success: function(data) {
                    var notifications = JSON.parse(data);
                    if (notifications.length > 0) {
                        notifications.forEach(function(notification) {
                            $('#notificationList').append(
                                '<li class="list-group-item">' +
                                    '<strong>Customer Name:</strong> ' + notification.cname + '<br>' +
                                    '<strong>Customer Address:</strong> ' + notification.cadd + '<br>' +
                                    '<strong>Customer Phone:</strong> ' + notification.cphn + '<br>' +
                                    '<strong>Waste Type:</strong> ' + notification.type + '<br>' +
                                    '<strong>Comments/Status:</strong> ' + notification.comments + '<br>' +
                                    '<strong>Notification Time:</strong> ' + notification.time + '<br>' +
                                    '<button class="btn btn-success mark-reviewed-btn" data-id="' + notification.nid + '">Reviewed</button>' +
                                '</li>'
                            );
                        });
                    } else {
                        $('#notificationList').append('<li class="list-group-item">No notifications found.</li>');
                    }
                    $('#notifyModal').modal('show');
                }
            });
        });

        $(document).on('click', '.mark-reviewed-btn', function() {
            var notificationId = $(this).data('id');
            console.log('Marking as reviewed: ', notificationId); // Debugging output
        
            $.ajax({
                type: 'POST',
                url: 'save_changes.php',
                data: { mark_reviewed: true, id: notificationId },
                success: function(response) {
                    console.log('Response: ' + response); // Debugging output
                    if (response === 'success') {
                        $('button[data-id="' + notificationId + '"]').closest('li').remove();
                    } else {
                        alert('Failed to mark as reviewed. Response: ' + response);
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Error: ' + error);
                    console.log('Status: ' + status);
                    console.log('Response: ' + xhr.responseText);
                }
            });
        });
    </script>

    <!-- Modal for Notifications -->
    <div class="modal fade" id="notifyModal" tabindex="-1" aria-labelledby="notifyModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="notifyModalLabel">Notifications</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <ul id="notificationList" class="list-group">
                        <!-- Notifications will be appended here -->
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>


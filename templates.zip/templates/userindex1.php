<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css\style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khojki&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ url_for('static', filename='bootstrap/css/bootstrap.min.css') }}">
<script src="{{ url_for('static', filename='bootstrap/js/bootstrap.min.js') }}"></script>
</head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">     EcoSwapHub : Recycling Wastes</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="page1.php">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      
  </ul>
  </div>
</nav>
<br>
<br>
<br>

 


<section >
    <div class="py-2"><h2 class="text-center">REGISTER</h2></div>



<div class="container  mx-auto  custom-form">
<form action="userdata.php" method="post"> 
  <div class="form-row" >

  <div class="form-group col-md-6">
      <label for="name">FullName</label>
      <input type="text" class="form-control" id="name" name="name" autocomplete="off" placeholder="Name">
    </div>
    
    <div class="form-group col-md-10">
      <label for="email">Email</label>
      <input type="email" class="form-control" id="email" name="email" autocomplete="off" placeholder="Email">
    </div>

    <div class="form-group col-md-4">
      <label for="pass"> Set Password</label>
      <input type="password" class="form-control" id="pass" name="pass" autocomplete="off" placeholder="Password">
    </div>
 
  <div class="form-group col-md-10">
    <label for="address">Address </label>
    <input type="text" class="form-control" id="address" name="address" autocomplete="off" placeholder="1234 Main Street..">
  </div>
  
   <div class="form-group col-md-4">
      <label for="city">City</label>
      <input type="text" class="form-control" id="city" name="city" autocomplete="off">
    </div>

    <div class="form-group col-md-2">
      <label for="state">State</label>
      <select id="state" name="state" autocomplete="off" class="form-control">
        <option selected>Telangana</option>
        <option>AndhraPradesh</option>
        <option>Karnataka</option>
        <option>Maharashtra</option>
        <option>TamilNadu</option>
        <option>Kerala</option><option>MadhyaPradesh</option>
        <option>Punjab</option><option>Haryana</option>
      </select>
    </div>

    <div class="form-group col-md-2">
      <label for="pincode">Pincode</label>
      <input type="number" class="form-control" id="pincode" autocomplete="off" name="pincode">
    </div>

    <div class="form-group col-md-6">
      <label for="mobile">Mobile No.</label>
      <input type="number" class="form-control" id="mobile" name="mobile" autocomplete="off" placeholder="Mobile No.">
    </div>

    </div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Register</button>
  
 
</form>
</div>
</section>
<footer>
  <p class="p-3 bg-dark text-white text-center">@EcoSwapHub</p>
</footer>
<br>
<br>



</body>
</html>

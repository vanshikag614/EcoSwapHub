

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css\style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khojki&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">     EcoSwapHub : Recycling Wastes</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="page1.php">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      
  </ul>
  </div>
</nav>
<br>
<br>


  <div class="container mx-auto  custom-form">
    <h2>Trader Details</h2>
    <form action="traderdata.php" method="post">
      <!-- Identification and Contact Information -->
      <div class="form-group">
        <label for="traderName">Name of Individual or Organization:</label>
        <input type="text" class="form-control" id="tname" name="tname" autocomplete="off" required>
      </div>
      <div class="form-group">
        <label for="traderEmail">Email Address:</label>
        <input type="email" class="form-control" id="temail" name="temail" autocomplete="off" >
      </div>
      <div class="form-group">
        <label for="traderPhone">Phone Number:</label>
        <input type="tel" class="form-control" id="tphone" name="tphone"autocomplete="off" pattern="[0-9]{10}"  required >
        <small class="form-text text-muted">Format: 1234567890</small>
      </div>
      <div class="form-group">
        <label for="traderAddress">Physical Address:</label>
        <textarea class="form-control" id="taddress" name="taddress" autocomplete="off" rows="3"  required ></textarea>
      </div>
      
      <div class="form-group">
        <label for="websitelink">Website Link (if available):</label>
        <input type="text" class="form-control" id="websitelink" name="websitelink" autocomplete="off">
      </div>
      
      <!-- Recycling Product Requirements -->
      <h3>Recycling Product Requirements</h3>
      <div class="form-group">
        <label for="type">Types of wastes:</label>
        
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="plasticCheckbox" name="type[]" value="Plastic">
        <label class="form-check-label" for="plasticCheckbox">Plastic</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="paperCheckbox"name="type[]" value="Paper">
        <label class="form-check-label" for="paperCheckbox">Paper</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="glassCheckbox"name="type[]" value="Glass">
        <label class="form-check-label" for="glassCheckbox">Glass</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="metalCheckbox"name="type[]" value="Metal">
        <label class="form-check-label" for="metalCheckbox">Metal</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="organicCheckbox" name="type[]" value="Organic">
        <label class="form-check-label" for="organicCheckbox">Organic</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="lightbulbsCheckbox"name="type[]" value="Lightbulbs">
        <label class="form-check-label" for="lightbulbsCheckbox">Light Bulbs</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="ewasteCheckbox"name="type[]" value="Ewaste">
        <label class="form-check-label" for="ewasteCheckbox">E-Waste</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="clothesCheckbox"name="type[]" value="Clothes">
        <label class="form-check-label" for="clothesCheckbox">Clothes</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="batteriesCheckbox"name="type[]" value="Batteries">
        <label class="form-check-label" for="batteriesCheckbox">Batteries</label>
      </div>
</div>
      

      <div class="form-group">
        <label for="minquantity">Minimum Quantity Needed:</label>
        <input type="number" class="form-control"  id="minquantity" name="minquantity" autocomplete="off" >
      </div>
      
      
      <!-- Logistics and Transportation -->
      <h3>Logistics and Transportation</h3>
      
      <div class="form-group">
        <label for="locationrecycling">Location of Recycling Facility:</label>
        <input type="text" class="form-control" id="locationrecycling" name="locationrecycling" autocomplete="off"  required>
      </div>
      <div class="form-group">
        <label for="transportpreference">Transportation Preferences:</label>
        <select class="form-control" id="transportpreference" name="transportpreference" >
          <option value="own">Own Transportation facility available</option>
          <option value="others">No Transport facility</option>
        </select>
      </div>


      <div class="form-group">
        <label for="specialhandling">Special Handling or Shipping Requirements:</label>
        <textarea class="form-control" id="specialhandling" name="specialhandling" autocomplete="off" rows="3"></textarea>
      </div>
   
      
      <!-- Financial Information -->
      <h3>Financial Information</h3>
      
      <div class="form-group">
        <label for="paymentmethods">Accepted Payment Methods:</label>
       
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="cashCheckbox" name="paymentmethods[]" value="cash">
        <label class="form-check-label" for="cashCheckbox">Cash</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="cardCheckbox" name="paymentmethods[]" value="credit">
        <label class="form-check-label" for="cardCheckbox">Credit/Debit</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="chequeCheckbox" name="paymentmethods[]" value="cheque">
        <label class="form-check-label" for="chequeCheckbox">Cheque</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="upiCheckbox" name="paymentmethods[]" value="upi">
        <label class="form-check-label" for="upiCheckbox">UPI</label>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="allCheckbox" name="paymentmethods[]" value="all">
        <label class="form-check-label" for="allCheckbox">AllOfTheAbove</label>
      </div>
    
      </div>
      
      <!-- Legal and Regulatory Compliance -->
      <h3>Legal and Regulatory Compliance</h3>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="complianceCheck" required>
        <label class="form-check-label" for="complianceCheck">I confirm compliance with relevant environmental regulations and waste management laws.</label>
      </div>
      <div class="form-group">
        <label for="permitslicenses">Permits or Licenses (if applicable):</label>
        <textarea class="form-control" id="permitslicenses" name="permitslicenses" autocomplete="off" rows="3"></textarea>
      </div>
      
      
      <!-- Communication Preferences -->
      <h3>Communication Preferences</h3>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="communicationOptIn" required>
        <label class="form-check-label" for="communicationOptIn">I would like to receive updates, newsletters, or notifications about waste trading opportunities and recycled products.</label>
      </div>

      <!-- Terms of Service and Agreement -->
      <h3>Terms of Service and Agreement</h3>
      <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="termsCheck" required>
        <label class="form-check-label" for="termsCheck">I accept the terms of service and user agreements, and consent to privacy policies and data handling practices.</label>
      </div>
      

      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
  <footer>
  <p class="p-3 bg-dark text-white text-center">@EcoSwapHub</p>
</footer>
<br>
<br>
</body>
</html>

<?php include 'menu.php'; 
session_start(); 

// Database connection
$con = mysqli_connect('localhost', 'root', '', 'userdata');

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set a sample session variable for demonstration purposes
// In a real application, you should set this when the user logs in
if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = 'Guest'; // Replace with actual user name
}

$username = $_SESSION['username'];

// Initialize variables
$customerId = null;
$customerAd = null;
$customerPh = null;


if ($username != 'Guest') {
    $sql = "SELECT id, address, mobile FROM userdata WHERE name = '$username'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $customerId = $row['id'];
        $customerAd = $row['address'];
        $customerPh = $row['mobile'];
    }
} else {
    $guestWarning = "Guests are not allowed to notify.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $username != 'Guest') {
    if ($username == 'Guest') {
        $message = "Guests are not allowed to send notifications.";
    } else {
        if ($customerId !== null) {

    $customerName = mysqli_real_escape_string($con, $_POST['customerName']);
    $traderId = mysqli_real_escape_string($con, $_POST['traderId']);
    $traderName = mysqli_real_escape_string($con, $_POST['traderName']);
    $traderPhone = mysqli_real_escape_string($con, $_POST['traderPhone']);
    $traderAddress = mysqli_real_escape_string($con, $_POST['traderAddress']);
    $wasteType = mysqli_real_escape_string($con, $_POST['wasteType']);
    $comments = isset($_POST['comments']) ? mysqli_real_escape_string($con, $_POST['comments']) : '';
    $sql = "INSERT INTO notifications (cid, cname, cadd, cphn, tid, tname, tadd, tphn, type, status, comments, time) 
            VALUES ('$customerId','$customerName', '$customerAd','$customerPh', '$traderId', '$traderName', '$traderAddress', '$traderPhone', '$wasteType','Pending', '$comments', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i'))";

    if (mysqli_query($con, $sql)) {
        $message = "Notification saved successfully";
    } else {
        $message = "Error saving notification: " . mysqli_error($con);
    }
}
else {
    $message = "User details are missing. Unable to send notification.";
}
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recycling Units</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="container">
        <?php if (!empty($message)) { ?>
            <div id="notificationMessage" class="alert alert-info"><?php echo $message; ?></div>
            <script>
                $(document).ready(function() {
                    setTimeout(function() {
                        $('#notificationMessage').fadeOut();
                    }, 1000); // 3 seconds
                });
            </script>
        <?php } ?>
        <?php if (isset($guestWarning)) { ?>
            <div class="alert alert-warning"><?php echo $guestWarning; ?></div>
        <?php } ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                    <th>Website</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_GET['wasteType'])) {
                    $selectedWasteType = mysqli_real_escape_string($con, $_GET['wasteType']);
                    echo "<h2>Recycling Units for $selectedWasteType Waste</h2>";

                    // Query to retrieve recycling units data
                    $sql = "SELECT tname, tphone, taddress, websitelink, tid FROM traderdata WHERE type LIKE '%$selectedWasteType%'";
                    $result = mysqli_query($con, $sql);

                    // Display data in table rows
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['tname'] . "</td>";
                            echo "<td>" . $row['tphone'] . "</td>";
                            echo "<td>" . $row['taddress'] . "</td>";
                            echo "<td><a href='" . $row['websitelink'] . "'>" . $row['websitelink'] . "</a></td>";
                            echo "<td><button class='notify-btn btn btn-primary' data-tid='" . $row['tid'] . "' data-name='" . $row['tname'] . "' data-phone='" . $row['tphone'] . "' data-address='" . $row['taddress'] . "'>Notify</button></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No recycling units found</td></tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="notifyModal" tabindex="-1" aria-labelledby="notifyModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="notifyModalLabel">Notify Trader</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="notifyForm" method="POST">
                        <div class="form-group">
                            <label for="customerName">Customer Name</label>
                            <input type="text" class="form-control" id="customerName" name="customerName" value="<?php echo $_SESSION['username']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="traderName">Trader Name</label>
                            <input type="text" class="form-control" id="traderName" name="traderName" readonly>
                        </div>
                        <div class="form-group">
                            <label for="traderPhone">Phone</label>
                            <input type="text" class="form-control" id="traderPhone" name="traderPhone" readonly>
                        </div>
                        <div class="form-group">
                            <label for="traderAddress">Address</label>
                            <input type="text" class="form-control" id="traderAddress" name="traderAddress" readonly>
                        </div>
                        <div class="form-group">
                            <label for="wasteType">Type of Waste</label>
                            <input type="text" class="form-control" id="wasteType" name="wasteType" value="<?php echo $_GET['wasteType']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="comments">Any requirements/Comments</label>
                            <input type="text" class="form-control" id="comments" name="comments">
                        </div>
                        <input type="hidden" id="traderId" name="traderId">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).on('click', '.notify-btn', function() {
            var username = "<?php echo $_SESSION['username']; ?>";
            if (username === 'Guest') {
                alert('Guests are not allowed to notify.');
                return; // Exit function
            } else {
                var tid = $(this).data('tid');
                var name = $(this).data('name');
                var phone = $(this).data('phone');
                var address = $(this).data('address');

                // Fill the modal with trader's details
                $('#traderId').val(tid);
                $('#traderName').val(name);
                $('#traderPhone').val(phone);
                $('#traderAddress').val(address);

                // Show the modal
                $('#notifyModal').modal('show');
            }
        });
    </script>
</body>
</html>

<?php
// Close connection
mysqli_close($con);
?>

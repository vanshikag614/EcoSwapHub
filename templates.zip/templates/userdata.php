<?php
$con=mysqli_connect('localhost','root');
if($con){
    echo "connection successful";

}
else{
    echo "no connection ";
}

mysqli_select_db($con, 'userdata');

$name = $_POST['name'];
$email= $_POST['email'];
$pass = $_POST['pass'];
$address= $_POST['address'];
$city= $_POST['city'];
$state= $_POST['state'];
$pincode= $_POST['pincode'];
$mobile= $_POST['mobile'];

$query="insert into userdata (name,email,pass,address,city,state,pincode,mobile) 
values ('$name', '$email','$pass ','$address','$city','$state','$pincode','$mobile')";

mysqli_query($con,$query);
header('location:page1.php');
?>
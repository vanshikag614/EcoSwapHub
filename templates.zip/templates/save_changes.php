<?php
// Database connection
    $con = mysqli_connect('localhost', 'root');

    // Check connection
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
    mysqli_select_db($con, 'userdata');
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['mark_reviewed'])) {
        // Update the status of the notification to "Reviewed"
        $notificationId = $_POST['id'];
        
        $sql = "UPDATE notifications SET status='Reviewed' WHERE nid=?";
        $stmt = mysqli_prepare($con, $sql);
        
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $notificationId);
            mysqli_stmt_execute($stmt);
            
            if (mysqli_stmt_affected_rows($stmt) > 0) {
                echo 'success';
            } else {
                echo 'Failed to mark as reviewed. Affected rows: ' . mysqli_stmt_affected_rows($stmt);
            }

            mysqli_stmt_close($stmt);
        } 
        else {
            echo 'Failed to prepare statement.';
        }
    }
    
   else{
    // Retrieve form data
    $tid = mysqli_real_escape_string($con, $_POST['tid']); // Sanitize input
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $website = mysqli_real_escape_string($con, $_POST['website']);

    // Update the record in the database
    $sql = "UPDATE traderdata SET tname='$name', tphone='$phone', taddress='$address', temail='$email', websitelink='$website' WHERE tid=$tid";
    if (mysqli_query($con, $sql)) {
        echo "Changes saved successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
   }
}
    // Close connection
    mysqli_close($con);
    
        exit();


?>


    
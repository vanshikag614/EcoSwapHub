<?php
session_start();
if (session_status() === PHP_SESSION_ACTIVE) {
  echo "Session is active.<br>";
} else {
  echo "Session not active.<br>";
}

if (isset($_SESSION['username'])) {
  echo "Session name set: " . $_SESSION['username'];
} else {
  echo "Session name not set.";
}


// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to webpage1.php
    $_SESSION['username'] = "guest";
    header("Location: webpage1.php");
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css\style.scss">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khojki&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">     EcoSwapHub : Recycling Wastes</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="page1.php">Home <span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Login
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="traderindex1.php">Traderlogin</a>
          <a class="dropdown-item" href="userindex1.php">Customerlogin</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php">SignOut</a>

        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <?php if (isset($_SESSION['username']) && !empty($_SESSION['username'])) { ?>
            <a class="nav-link" href="#"><?php echo $_SESSION['username']; ?></a>
        <?php } else { ?>
            <a class="nav-link" href="#">Guest</a>
        <?php } ?>
    </li>
      
    </ul>
  </div>
</nav>
<br>
<br>
<br>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="https://www.zerowaste.com/wp-content/uploads/2020/09/Woman-recycling-768x512.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="https://upload.wikimedia.org/wikipedia/commons/c/c3/Municipal_recycling_facilities%2C_Montgomery_County%2C_MD._2007%2C_Credit_USEPA_%2814410405277%29.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="https://cdn.wm.com/content/dam/wm/assets/recycle-right/recycling-resources/home-waving.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<style>
  
  .container {
  background-color: #ffffff;
  padding: 20px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  margin: 0 auto;
  /* display: flex;  */
  justify-content: center;
}

input[type="file"] {
  display: none;
}

label {
  display: block;
  background-color: #4caf50;
  color: #fff;
  padding: 10px;
  text-align: center;
  border-radius: 4px;
  cursor: pointer;
}

label:hover {
  background-color: #45a049;
}

#submitBtn {
  margin-top: 10px;
  background-color: #008CBA;
  color: #fff;
  padding: 10px;
  border-radius: 4px;
  cursor: pointer;
}

#submitBtn:hover {
  background-color: #005d7a;
}

  /* CSS to adjust margins of the paragraph */
  .custom-paragraph {
    margin-top: 20px; /* Adjust top margin */
    margin-bottom: 20px; /* Adjust bottom margin */
    margin-left: 280px; /* Adjust left margin */
    margin-right: 80px; /* Adjust right margin */
  }
  p {
    font-family:arial; /* Specify the font family */
    font-size: 16px; /* Specify the font size */
    
    color: #696969; /* Specify the font color */
    /* Add any other font properties as needed */
}
ul{
  font-family:arial; /* Specify the font family */
    font-size: 16px; /* Specify the font size */
    
    color: #696969;
}

</style>
<br><br> 

<section class="custom-paragraph">
  <h1>Why Recycle?</h1>
      <div class="introduction">
          
      </div>
          <!-- MAIN CONTENT -->
<br><br><br>
     <div><p>Recycling is easy to do and really can make a difference.</p></div>
      
     
        
            <div class="custom-list">
                <div class="custom-list--icon">
                    <img src="https://www.brysonrecycling.org/images/uploads/icons/collaboration-icon.png" alt="">
                </div><!----><div class="custom-list--copy">
                    <h3>Recycling conserves resources</h3>
                    <p>When we recycle, materials are converted into new products, reducing the need to consume natural resources which will help to protect natural habitats for the future.</p>
                </div>
            </div>
        
            <div class="custom-list">
                <div class="custom-list--icon">
                    <img src="https://www.brysonrecycling.org/images/uploads/icons/empowering-icon.png" alt="">
                </div><!----><div class="custom-list--copy">
                    <h3>Recycling saves energy</h3>
                    <p>Using recycled materials in the manufacturing process uses considerably less energy than that required for producing new products from raw materials.</p>
                </div>
            </div>
        
            <div class="custom-list">
                <div class="custom-list--icon">
                    <img src="https://www.brysonrecycling.org/images/uploads/icons/excellence-icon.png" alt="">
                </div><!----><div class="custom-list--copy">
                    <h3>Recycling helps protect the environment</h3>
                    <p>Recycling reduces the need for extracting, refining and processing raw materials all of which create air and water pollution.</p>

<p>As recycling saves energy it also reduces greenhouse gas emissions, which helps to tackle climate change.</p>
                </div>
            </div>
        
            <div class="custom-list">
                <div class="custom-list--icon">
                    <img src="https://www.brysonrecycling.org/images/uploads/icons/innovation-icon.png" alt="">
                </div><!----><div class="custom-list--copy">
                    <h3>Recycling reduces landfill</h3>
                    <p>When we recycle, recyclable materials are reprocessed into new products, and as a result the amount of rubbish sent to landfill sites decreases which reduces emissions of methane, a powerful greenhouse gas.</p>
                </div>
            </div>
        </section>



<section class=my-5>
    <div class="py-5">
      <h1 align="center">Categories</h1>
    </div>
      <div class="container-fluid">
        <div class="row">
  
        <div class="col-lg-4 col-md-4 col-12">
  <div class="card" >
    <img class="card-img-top" src="https://t3.ftcdn.net/jpg/00/31/73/96/360_F_31739615_0MCEWMyShfV6k7uvsh6vBUHAib0D48yv.jpg" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Metal</h4>
      
      <a href="#" class="btn btn-primary" id="metalButton" onclick="getRecyclingUnits('Metal')">Metal</a>
    </div>
   </div>
   </div>
  
  
   <div class="col-lg-4 col-md-4 col-12">
  <div class="card">
    <img class="card-img-top" src="https://www.shutterstock.com/image-photo/stack-clothes-different-colors-box-260nw-2261776225.jpg" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Clothes</h4>
      
      <a href="#" class="btn btn-primary" id="clothesButton" onclick="getRecyclingUnits('Clothes')">Clothes</a>
    </div>
   </div>
   </div>
  
   <div class="col-lg-4 col-md-4 col-12">
  <div class="card" >
    <img class="card-img-top" src="https://www.shutterstock.com/image-photo/black-mesh-waste-bin-filled-260nw-1027277983.jpg" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Paper</h4>
      
      <a href="#" class="btn btn-primary" id="paperButton" onclick="getRecyclingUnits('Paper')">Paper</a>
    </div>
   </div>
   </div>
  
  </div>
  <br>
  <br>
  
  <div class="row">
  
        <div class="col-lg-4 col-md-4 col-12">
  <div class="card" >
    <img class="card-img-top" src="https://www.shutterstock.com/image-photo/separate-collection-glass-garbage-colorful-260nw-2184486739.jpg" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Glass</h4>
      
      <a href="#" class="btn btn-primary" id="glassButton" onclick="getRecyclingUnits('Glass')">Glass</a>
    </div>
   </div>
  </div>
  
  
   <div class="col-lg-4 col-md-4 col-12">
  <div class="card">
    <img class="card-img-top" src="https://www.shutterstock.com/image-photo/spilled-garbage-on-beach-big-260nw-1086143246.jpg" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Plastic</h4>
      
      <a href="#" class="btn btn-primary" id="plasticButton" onclick=" getRecyclingUnits('plastic')">Plastic</a>
     
    </div> </div></div>
  
   <div class="col-lg-4 col-md-4 col-12">
  <div class="card" >
    <img class="card-img-top" src="https://www.shutterstock.com/image-photo/male-hand-throws-light-bulb-260nw-2215457013.jpg" alt="lightbulbs">
    <div class="card-body">
      <h4 class="card-title" align="center">Light Bulbs</h4>
      
      <a href="#" class="btn btn-primary"  id="lightbulbsButton" onclick="getRecyclingUnits('lightbulbs')">Light Bulbs</a>
    </div></div></div>
  </div>
  <br>
  <br>
  
  <div class="row">
  
        <div class="col-lg-4 col-md-4 col-12">
  <div class="card" >
    <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6UDqaNvbW07EXRzNiewq3l_o3UNuL5QNZ5w&usqp=CAU" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Batteries</h4>
      
      <a href="#" class="btn btn-primary" id="batteriesButton"  onclick="getRecyclingUnits('batteries')">Batteries</a>
    </div>
   </div>
  </div>
  
  
   <div class="col-lg-4 col-md-4 col-12">
  <div class="card">
    <img class="card-img-top" src="https://t3.ftcdn.net/jpg/04/75/41/80/360_F_475418037_cBGd9R0Jjwdtvw7zMtgUXYOwz1nUaXGV.jpg" alt="Card image">
    <div class="card-body">
      <h4 class="card-title" align="center">Organic</h4>
      
      <a href="#" class="btn btn-primary" id="organicButton" onclick=" getRecyclingUnits('organic')">Organic</a>
     
    </div> </div></div>
  
    
  
   <div class="col-lg-4 col-md-4 col-12">
  <div class="card" >
    <img class="card-img-top" src="https://sonalmetacop.com/wp-content/uploads/2021/04/e-waste-management-1030x686-1.jpg" alt="ewaste">
    <div class="card-body">
      <h4 class="card-title" align="center">Ewaste</h4>
      
      <style>
        .btn {
          padding: 10px 20px; /* Adjust padding as needed */
        justify-content: center; align-items: center; }
      </style>
      <a href="#" class="btn btn-primary"  id="ewasteButton" onclick="getRecyclingUnits('ewaste')">Ewaste</a>
      
    </div></div></div>
  
  </div>
  
  </div>
  <script>
          function getRecyclingUnits(wasteType) {
              window.location.href = "details.php?wasteType=" + wasteType;
          }
      </script>
  </section>



  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
      
  
  
  <footer>
    <p class="p-3 bg-dark text-white text-center">@EcoSwapHub</p>
  </footer>
  
  </body>
  </html>



<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css\style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khojki&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">     EcoSwapHub : Recycling Wastes</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="page1.php">Home <span class="sr-only"></span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="about.php">About</a>
      </li>
      

     <!-- <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Login
  </a>
  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
    <a class="dropdown-item" href="traderindex.php">Traderlogin</a>
    <a class="dropdown-item" href="userindex.php">Customerlogin</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="home.php">SignOut</a>
  </div>
</li>-->


      <li class="nav-item">
        <a class="nav-link" href="#">Gallery</a>
      </li>
    </ul>
    <!--<form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>-->
  </div>
</nav>
<br>
<br>
<br>

<main class="mt-5">
  <div class="container">
    <!--Section: Content-->
    <section>
      <div class="row">
        <div class="col-md-6 gx-5 mb-4">
          <div class="bg-image hover-overlay shadow-2-strong" data-mdb-ripple-init data-mdb-ripple-color="light">
            <img src="https://media.istockphoto.com/id/1015961600/photo/trash-box-for-recycle-and-reduce-ecology-environment-concept-save-the-earth.jpg?s=612x612&w=0&k=20&c=Sa2vZV8_tEbziTH_xZmqHfpWGrWOchCTDrWMIXQgcS0=" class="img-fluid" />
            <a href="#!">
              <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
            </a>
          </div>
        </div>

        <div class="col-md-6 gx-5 mb-4">
          <h4><strong>ABOUT US</strong></h4>
          <p class="text-muted" style="font-size: larger;">
            “Earth doesn’t belong to man, rather man belongs to the Earth.” It is our primary responsibility to precisely take care of where we belong to. 
            And what other than recycling can contribute to fulfilling this core and primary responsibility?
            Are we participating to our fullest in carrying out recycling practices or are we lacking somewhere? Yes, we are lacking out and the statistics
             presented here are evidence of what was said.
            So, without any further delay, it’s time to fix the recycling problems that are being faced such as the major connection between the recycling
             units and people who are interested in recycling wastes. Hence we've comeup with a website which provides a connection between the traders(recycling units) and customers.
             After all, our aim is to ensure that what we recycle actually gets recycled.
          </p>
          <p style="font-size: larger;"> <strong>Features of our website:</strong></p>
          <p class="text-muted" >
            <li style="font-size: larger;">User friendly interface.</li>
            <li style="font-size: larger;">ML model to classify their waste type.</li>
            <li style="font-size: larger;">Database to store all customers and traders.</li>
            <li style="font-size: larger;">Educational content on waste reduction.</li>
            <li style="font-size: larger;">Awareness on sustainable practices.</li>
          </p>
        </div>
      </div>
    </section>
    <style>
      /* CSS to adjust margins of the paragraph */
      .custom-paragraph {
        margin-top: 20px; /* Adjust top margin */
        margin-bottom: 20px; /* Adjust bottom margin */
        margin-left: 50px; /* Adjust left margin */
        margin-right: 50px; /* Adjust right margin */
      }
    </style>
    <section class="custom-paragraph" >
      <p style="font-size: larger;" align="center"> <strong>INDIA and its SOLID WASTE MANAGEMENT
      </strong></p>
      <p class="text-muted"  style="font-size: larger;">
        Due to rapid urbanization, economic growth and higher rates of urban consumption,
         India is among the world’s top 10 countries generating municipal solid wastes.
         According to a report by The Energy and Resources Institute (TERI), India generates
          over 62 million tons (MT) of waste in a year.  Only 43 MT of total waste generated
           gets collected, with 12 MT being treated before disposal, and the remaining 31 MT
            simply discarded in wasteyards. Most of the waste generated remains untreated and
             even unaccounted for. Inadequate waste collection, transport, treatment, and 
             disposal have become major causes for environmental and public health concerns
              in the country. 
<br><br>  The market for solid waste management in India can be segmented into various
               categories, such as collection, transportation, treatment, and disposal. 
               The collection and transportation segments account for the largest share 
               of the market due to the lack of proper collection and transportation 
               infrastructure. The treatment and disposal segments are expected to witness 
               significant growth during the forecast period due to the increasing focus on
                sustainable waste management practices.
      </section> 
    <!--Section: Content-->

    <section class="custom-paragraph" >
      <p style="font-size: larger;" align="center"> <strong>Our Contribution</strong></p>
      <p class="text-muted"  style="font-size: larger;">
        The solid waste management sector in India is expected to witness significant
         growth in the coming years, driven by factors such as increasing urbanization,
          rising awareness of waste management, and growing investments in waste management
           infrastructure.

U.S. companies offering innovative technologies, equipment, and cost-efficient waste handling 
systems and solutions - especially for waste sorting; recycling of plastic, tire, e-waste,
and batteries; construction waste management, landfill design and technologies; and solutions
generating energy from waste - will find multiple opportunities in India.
<br><br>  
Hence we're trying to classify these wastes broadly into 9 different categories mainly,
BATTERIES, METAL, ORGANIC, CLOTHES, LIGHT BULBS, GLASS, E-WASTE, PAPER and PLASTIC.
So that its easy to trade based on the type of waste and it reaches to the correct recycling unit.
      </section>
    <!--Section: Content-->


    <hr class="my-5" />

  
      

      <div class="row">
        <div class="col-lg-4 col-md-12 mb-4">
          <div class="card">
            <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
              <img src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/201907/landfill.jpeg?VersionId=BORohPNXyW8CwlajYumU.m.xbaDJB.7R&size=690:388" class="img-fluid" />
              <a href="#!">
                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
              </a>
            </div>
            <div class="card-body">
              <h5 class="card-title">India's Trash Bomb: 80% of 1.5 lakh metric tonne daily garbage remains 
                exposed, untreated</h5>
          
              <a href="https://www.indiatoday.in/india/story/india-s-trash-bomb-80-of-1-5-lakh-metric-tonne-daily-garbage-remains-exposed-untreated-1571769-2019-07-21" class="btn btn-primary" data-mdb-ripple-init>View Article</a>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
          <div class="card">
            <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
              <img src="https://www.nextias.com/blog/wp-content/uploads/2023/09/Waste-Management.jpg" class="img-fluid" />
              <a href="#!">
                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
              </a>
            </div>
            <div class="card-body">
              <h5 class="card-title">Waste Management: Facts, Challenges & Solutions</h5>
              
              <a href="https://www.nextias.com/blog/waste-management-in-india/#:~:text=What%20is%20the%20Biggest%20Problem,landfills%20instead%20of%20being%20recycled." class="btn btn-primary" data-mdb-ripple-init>View Article</a>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
          <div class="card">
            <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
              <img src="https://media.licdn.com/dms/image/D4D12AQE8YnIomksUTA/article-inline_image-shrink_1500_2232/0/1685943066180?e=1720051200&v=beta&t=0Vcm5Tw0U2GHyq_cU8woeS8uWXHqgnlt7BqOgQuvtzE" class="img-fluid" />
              <a href="#!">
                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
              </a>
            </div>
            <div class="card-body">
              <h5 class="card-title">Towards Sustainable Future: India's Commitment to the Environment</h5>
              <p class="card-text">
                Some quick example text to build on the card title and make up the bulk of the
                card's content.
              </p>
              <a href="https://www.linkedin.com/pulse/towards-sustainable-future-indias-commitment-environment/" class="btn btn-primary" data-mdb-ripple-init>View Article</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Section: Content-->

    <hr class="my-5" />
    <style>
      .custom-button {
  width: 45%; /* Adjust the width as needed */
  height: 65px; /* Adjust the height as needed */
  /* You can also add other styles like padding, margin, etc. */
  margin-right: 10px;
  font-size: 15px;
}
</style>

      <hr class="my-5" />
      
    <!--Section: Content-->


  </body>
</html>











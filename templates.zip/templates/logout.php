<?php
// Start the session
session_start();

// Unset session variable
unset($_SESSION['username']);

// Destroy the session
session_destroy();

// Redirect to webpage1.php
header("Location: webpage1.php");
exit();
?>

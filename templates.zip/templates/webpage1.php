<?php
session_start();
if (isset($_SESSION['username'])) {
  echo "Session name set: " . $_SESSION['username'];
} else {
  echo "Session name not set.";
}
//Debug: Check if session is active
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "Session is active.<br>";
} else {
    echo "Session not active.<br>";
}

// Check if the user is already logged in
if (isset($_SESSION['username'])) {
    // If logged in, redirect to page1.php
    header("Location: page1.php");
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password'])) {
    // Database connection
    $con = mysqli_connect('localhost', 'root');

    // Check connection
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
    mysqli_select_db($con, 'userdata');

    // Retrieve form data
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Query the database to check if the user exists
    $sql = "SELECT * FROM userdata WHERE name='$username' AND pass='$password'";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) == 1) {
        // User exists, set session variable and redirect to page1.php
        $_SESSION['username'] = $username;
        header("Location: page1.php");
        exit();
    } else {
        // User doesn't exist or incorrect password, display error message
        $error = "Invalid name or password!";
    }
    
    mysqli_close($con);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.0.0/css/all.css" />
    <!-- Google Fonts Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />


    <style>
      /* Carousel styling */
      #introCarousel,
      .carousel-inner,
      .carousel-item,
      .carousel-item.active {
        height: 100vh;
      }

      .carousel-item:nth-child(1) {
        background-image: url('https://t3.ftcdn.net/jpg/05/69/59/54/360_F_569595469_CgLGK97WF8hGGKTIBrRkPiz4j2FyoLxJ.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
      }

      .carousel-item:nth-child(2) {
        background-image: url('https://mdbootstrap.com/img/Photos/Others/images/77.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
      }

      .carousel-item:nth-child(3) {
        background-image: url('https://media.istockphoto.com/id/538798184/photo/recycling-awareness.jpg?s=612x612&w=0&k=20&c=yi713dboRVEafxGkw0nlqJ7ixT_GCiQRC0QOCcQbg-M=');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
      }

      /* Height for devices larger than 576px */
      @media (min-width: 992px) {
        #introCarousel {
          margin-top: -58.59px;
        }
      }

      .navbar .nav-link {
        color: #fff !important;
      }
      .button-91 {
  color: #fff;
  padding: 15px 25px;
  background-color: #38D2D2;
  background-image: radial-gradient(93% 87% at 87% 89%, rgba(0, 0, 0, 0.23) 0%, transparent 86.18%), radial-gradient(66% 66% at 26% 20%, rgba(255, 255, 255, 0.55) 0%, rgba(255, 255, 255, 0) 69.79%, rgba(255, 255, 255, 0) 100%);
  box-shadow: inset -3px -3px 9px rgba(255, 255, 255, 0.25), inset 0px 3px 9px rgba(255, 255, 255, 0.3), inset 0px 1px 1px rgba(255, 255, 255, 0.6), inset 0px -8px 36px rgba(0, 0, 0, 0.3), inset 0px 1px 5px rgba(255, 255, 255, 0.6), 2px 19px 31px rgba(0, 0, 0, 0.2);
  border-radius: 14px;
  font-weight: bold;
  font-size: 16px;

  border: 0;

  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;

  cursor: pointer;
}
    </style>
</head>
<body>
      <!--Main Navigation-->
  <header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark d-none d-lg-block" style="z-index: 2000;">
    <div class="container-fluid">
        <!-- Navbar brand -->
        <a class="navbar-brand" href="#">     EcoSwapHub : Recycling Wastes</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
        
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="page1.php">Home <span class="sr-only"></span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <!--<li class="nav-item ">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Register
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="traderindex1.php">Trader</a>
          <a class="dropdown-item" href="userindex1.php">Customer</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="webpage1.php">SignOut</a>
        </div>
      </li>-->
      
    </ul>
    
  </div>
 <ul class="navbar-nav list-inline">
            <!-- Icons -->

            
            <li class="nav-item">
              <a class="nav-link" href="https://github.com/vanshikag614/EcoSwapHub.git" rel="nofollow" target="_blank">
                <i class="fab fa-github"></i>
              </a>
            </li>
          </ul>
    </div>
      </div>
    </nav>
    <!-- Navbar -->

    <!-- Carousel wrapper -->
    <div id="introCarousel" class="carousel slide carousel-fade shadow-2-strong" data-mdb-carousel-init>
      <!-- Indicators -->
      <div class="carousel-indicators">
        <li data-mdb-target="#introCarousel" data-mdb-slide-to="0" class="active"></li>
        <li data-mdb-target="#introCarousel" data-mdb-slide-to="1"></li>
        <li data-mdb-target="#introCarousel" data-mdb-slide-to="2"></li>
      </div>

      <!-- Inner -->
      <div class="carousel-inner">
        <!-- Single item -->
        <div class="carousel-item active">
          <div class="mask" style="background-color: rgba(0, 0, 0, 0.6);">
            <div class="d-flex justify-content-center align-items-center h-100">
              <div class="text-white text-center" data-mdb-theme="dark">
              <h1 class="mb-3"> ECO SWAP HUB </h1>
              <h3 class="mb-4">Recycling wastes</h3>
                
              </div>
            </div>
          </div>
        </div>

        <!-- Single item -->
        <div class="carousel-item">
          <div class="mask" style="background-color: rgba(0, 0, 0, 0.3);">
            <div class="d-flex justify-content-center align-items-center h-100">
              <div class="text-white text-center">
                <h2>Make this place a better place to live!</h2>
              </div>
            </div>
          </div>
        </div>

        <!-- Single item -->
        <div class="carousel-item">
          <div class="mask" style="
                background: linear-gradient(
                  45deg,
                  rgba(29, 236, 197, 0.7),
                  rgba(91, 14, 214, 0.7) 100%
                );
              ">
            <div class="d-flex justify-content-center align-items-center h-100" data-mdb-theme="dark">
              <div class="text-white text-center">
                <h2></h2>
                <a class="btn btn-outline-light btn-lg m-2" data-mdb-ripple-init
                  href="" target="_blank" role="button"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Inner -->

      <!-- Controls -->
      <a class="carousel-control-prev" href="#introCarousel" role="button" data-mdb-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#introCarousel" role="button" data-mdb-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    <!-- Carousel wrapper -->
  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main class="mt-5">
    <div class="container">
      <!--Section: Content-->
      <section>
        <div class="row">
          <div class="col-md-6 gx-5 mb-4">
            <div class="bg-image hover-overlay shadow-2-strong" data-mdb-ripple-init data-mdb-ripple-color="light">
              <img src="https://media.istockphoto.com/id/1015961600/photo/trash-box-for-recycle-and-reduce-ecology-environment-concept-save-the-earth.jpg?s=612x612&w=0&k=20&c=Sa2vZV8_tEbziTH_xZmqHfpWGrWOchCTDrWMIXQgcS0=" class="img-fluid" />
              <a href="#!">
                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
              </a>
            </div>
          </div>

          <div class="col-md-6 gx-5 mb-4">
            <h4><strong>ABOUT US</strong></h4>
            <p class="text-muted" style="font-size: larger;">
              “Earth doesn’t belong to man, rather man belongs to the Earth.” It is our primary responsibility to precisely take care of where we belong to. 
              And what other than recycling can contribute to fulfilling this core and primary responsibility?
              Are we participating to our fullest in carrying out recycling practices or are we lacking somewhere? Yes, we are lacking out and the statistics
               presented here are evidence of what was said.
              So, without any further delay, it’s time to fix the recycling problems that are being faced such as the major connection between the recycling
               units and people who are interested in recycling wastes. Hence we've comeup with a website which provides a connection between the traders(recycling units) and customers.
               After all, our aim is to ensure that what we recycle actually gets recycled.
            </p>
            <p style="font-size: larger;"> <strong>Features of our website:</strong></p>
            <p class="text-muted" >
              <li style="font-size: larger;">User friendly interface.</li>
              <li style="font-size: larger;">ML model to classify their waste type.</li>
              <li style="font-size: larger;">Database to store all customers and traders.</li>
              <li style="font-size: larger;">Educational content on waste reduction.</li>
              <li style="font-size: larger;">Awareness on sustainable practices.</li>
            </p>
          </div>
        </div>
      </section>
      <style>
        /* CSS to adjust margins of the paragraph */
        .custom-paragraph {
          margin-top: 20px; /* Adjust top margin */
          margin-bottom: 20px; /* Adjust bottom margin */
          margin-left: 50px; /* Adjust left margin */
          margin-right: 50px; /* Adjust right margin */
        }
      </style>
      <section class="custom-paragraph" >
        <p style="font-size: larger;" align="center"> <strong>INDIA and its SOLID WASTE MANAGEMENT
        </strong></p>
        <p class="text-muted"  style="font-size: larger;">
          Due to rapid urbanization, economic growth and higher rates of urban consumption,
           India is among the world’s top 10 countries generating municipal solid wastes.
           According to a report by The Energy and Resources Institute (TERI), India generates
            over 62 million tons (MT) of waste in a year.  Only 43 MT of total waste generated
             gets collected, with 12 MT being treated before disposal, and the remaining 31 MT
              simply discarded in wasteyards. Most of the waste generated remains untreated and
               even unaccounted for. Inadequate waste collection, transport, treatment, and 
               disposal have become major causes for environmental and public health concerns
                in the country. 
<br><br>  The market for solid waste management in India can be segmented into various
                 categories, such as collection, transportation, treatment, and disposal. 
                 The collection and transportation segments account for the largest share 
                 of the market due to the lack of proper collection and transportation 
                 infrastructure. The treatment and disposal segments are expected to witness 
                 significant growth during the forecast period due to the increasing focus on
                  sustainable waste management practices.
        </section> 
      <!--Section: Content-->

      <section class="custom-paragraph" >
        <p style="font-size: larger;" align="center"> <strong>Our Contribution</strong></p>
        <p class="text-muted"  style="font-size: larger;">
          The solid waste management sector in India is expected to witness significant
           growth in the coming years, driven by factors such as increasing urbanization,
            rising awareness of waste management, and growing investments in waste management
             infrastructure.

U.S. companies offering innovative technologies, equipment, and cost-efficient waste handling 
systems and solutions - especially for waste sorting; recycling of plastic, tire, e-waste,
 and batteries; construction waste management, landfill design and technologies; and solutions
  generating energy from waste - will find multiple opportunities in India.
<br><br>  
Hence we're trying to classify these wastes broadly into 9 different categories mainly,
BATTERIES, METAL, ORGANIC, CLOTHES, LIGHT BULBS, GLASS, E-WASTE, PAPER and PLASTIC.
So that its easy to trade based on the type of waste and it reaches to the correct recycling unit.
        </section>
      <!--Section: Content-->


      <hr class="my-5" />

      <!--Section: Content-->
      <section class="text-center">
        <h4 class="mb-5"><strong>CLASSIFY THE WASTE INTO A CATEGORY!!</strong></h4>
        

        <button class="button-91" onclick="redirectToFlaskModel()">Click Here!</button>
        <br><br>
        <br><br>
        <script>
          function redirectToFlaskModel() {
              window.location.href = 'http://localhost:5000/model'; // Change URL if necessary
          }
      </script>

        <div class="row">
          <div class="col-lg-4 col-md-12 mb-4">
            <div class="card">
              <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
                <img src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/201907/landfill.jpeg?VersionId=BORohPNXyW8CwlajYumU.m.xbaDJB.7R&size=690:388" class="img-fluid" />
                <a href="#!">
                  <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                </a>
              </div>
              <div class="card-body">
                <h5 class="card-title">India's Trash Bomb: 80% of 1.5 lakh metric tonne daily garbage remains 
                  exposed, untreated</h5>
            
                <a href="https://www.indiatoday.in/india/story/india-s-trash-bomb-80-of-1-5-lakh-metric-tonne-daily-garbage-remains-exposed-untreated-1571769-2019-07-21" class="btn btn-primary" data-mdb-ripple-init>View Article</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card">
              <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
                <img src="https://www.nextias.com/blog/wp-content/uploads/2023/09/Waste-Management.jpg" class="img-fluid" />
                <a href="#!">
                  <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                </a>
              </div>
              <div class="card-body">
                <h5 class="card-title">Waste Management: Facts, Challenges & Solutions</h5>
                
                <a href="https://www.nextias.com/blog/waste-management-in-india/#:~:text=What%20is%20the%20Biggest%20Problem,landfills%20instead%20of%20being%20recycled." class="btn btn-primary" data-mdb-ripple-init>View Article</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card">
              <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
                <img src="https://media.licdn.com/dms/image/D4D12AQE8YnIomksUTA/article-inline_image-shrink_1500_2232/0/1685943066180?e=1720051200&v=beta&t=0Vcm5Tw0U2GHyq_cU8woeS8uWXHqgnlt7BqOgQuvtzE" class="img-fluid" />
                <a href="#!">
                  <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                </a>
              </div>
              <div class="card-body">
                <h5 class="card-title">Towards Sustainable Future: India's Commitment to the Environment</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up the bulk of the
                  card's content.
                </p>
                <a href="https://www.linkedin.com/pulse/towards-sustainable-future-indias-commitment-environment/" class="btn btn-primary" data-mdb-ripple-init>View Article</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Content-->

      <hr class="my-5" />
      <style>
        .custom-button {
    width: 45%; /* Adjust the width as needed */
    height: 65px; /* Adjust the height as needed */
    /* You can also add other styles like padding, margin, etc. */
    margin-right: 10px;
    font-size: 15px;
  }
</style>


      <section class="mb-5">
        <h4 class="mb-5 text-center"><strong>SIGN UP/REGISTER!!!</strong></h4>
        <div class="row d-flex justify-content-center">
        
          <a href="userindex1.php" class="btn btn-primary btn-block mb-4 custom-button" data-mdb-ripple-init>FOR CUSTOMER</a>
          <br>
          <br>
          <a href="traderindex1.php" class="btn btn-primary btn-block mb-4 custom-button" data-mdb-ripple-init>FOR TRADER</a>

            <hr class="my-5" />  
      <!--Section: Content-->

      <section class="mb-5">
        <h4 class="mb-5 text-center"><strong>CUSTOMER LOGIN</strong></h4>

        <div class="row d-flex justify-content-center">
          <div class="col-md-6">
          
              <!-- 2 column grid layout with text inputs for the first and last names -->
              <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
              <div class="row mb-4">
                <div class="col">
                  <div class="form-outline" data-mdb-input-init >
                    <input type="text" id="username" name="username"class="form-control"/>
                    <label class="form-label" for="username">Full name</label>
                  </div>
                </div>
                
              </div>


              <!-- Password input -->
              <div class="form-outline mb-4" data-mdb-input-init >
                <input type="password" id="password"  name="password" class="form-control" />
                <label class="form-label" for="password">Password</label>
              </div>

              

              <!-- Submit button -->
              <button type="submit" class="btn btn-primary btn-block mb-4" data-mdb-ripple-init>SIGN IN</a>
              
                <!-- Error message -->
                <?php if (isset($error)) { ?>
                  <div class="alert alert-danger" role="alert">
                    <?php echo $error; ?>
                  </div>
                <?php } ?>

            </form>
          </div>
        </div>
      </section>
      <section class="mb-5">
        <div class="row d-flex justify-content-center">
          <div class="col-md-6">
            <a href="page1.php" class="btn btn-primary btn-block mb-4" data-mdb-ripple-init>LOGIN AS GUEST</a>
            
          </div>
        </section>
      <!--Section: Content-->
      <section class="mb-5">
        <h4 class="mb-5 text-center"><strong>VIEW TRADERS</strong></h4>
        <div class="row d-flex justify-content-center">
          <div class="col-md-6">
            <button type="button" class="btn btn-primary btn-block mb-4" data-toggle="modal" data-target="#loginModal">VIEW TRADERS</button>
          </div>
        </section>
        <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title" id="loginModalLabel">Admin Login</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                      <form id="loginForm" method="POST" action="viewtraders.php">
                          <div class="form-group">
                              <label for="adminName">Name</label>
                              <input type="text" class="form-control" id="adminName" name="adminName" required>
                          </div>
                          <div class="form-group">
                              <label for="adminPassword">Password</label>
                              <input type="password" class="form-control" id="adminPassword" name="adminPassword" required>
                          </div>
                          <button type="submit" class="btn btn-primary">Submit</button>
                      </form>
                  </div>
              </div>
          </div>
      </div>
      
      <!-- Bootstrap JS and dependencies -->
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      
      <script>
          // Optionally add any additional JavaScript here
          $(document).ready(function() {
              $('#loginForm').on('submit', function(event) {
                  // Additional validation or actions can be added here
              });
          });
      </script>

    </div>
  </main>
  <!--Main layout-->

  <!--Footer-->
  <footer>
    <p class="p-3 bg-light text-black text-center">@EcoSwapHub</p>
  </footer>
  
  
    <script type="text/javascript" src="js/mdb.umd.min.js"></script>
</body>
</html>


<?php
// Database connection
$con = mysqli_connect('localhost', 'root', '', 'userdata');

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$trader_id = $_GET['trader_id'];

// Query to fetch notifications
$sql = "SELECT nid, cname, cadd, cphn, type, time, status, comments FROM notifications WHERE tid = ? AND status != 'Reviewed'";
$stmt = mysqli_prepare($con, $sql);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, 'i', $trader_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $notifications = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $notifications[] = $row;
        }
    }

    // Close statement
    mysqli_stmt_close($stmt);
}

// Close connection
mysqli_close($con);

// Return notifications as JSON
echo json_encode($notifications);
?>
